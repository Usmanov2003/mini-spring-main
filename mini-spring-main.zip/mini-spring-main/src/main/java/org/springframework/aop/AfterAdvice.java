package org.springframework.aop;

import org.aopalliance.aop.Advice;

/**
 * 后置增强
 *
 * @author zqc
 * @date 2022/12/16
 */
public interface AfterAdvice extends Advice {
}
