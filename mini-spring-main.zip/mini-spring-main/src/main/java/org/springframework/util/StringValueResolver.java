package org.springframework.util;

/**
 * @author derekyi
 * @date 2020/12/27
 */
public interface StringValueResolver {

	String resolveStringValue(String strVal);
}
