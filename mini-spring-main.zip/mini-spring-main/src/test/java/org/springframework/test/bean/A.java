package org.springframework.test.bean;

/**
 * @author derekyi
 * @date 2021/1/25
 */
public class A {

	private B b;

	public void func(){}

	public B getB() {
		return b;
	}

	public void setB(B b) {
		this.b = b;
	}
}
