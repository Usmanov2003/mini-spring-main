package org.springframework.test.service;

/**
 * @author derekyi
 * @date 2020/12/6
 */
public interface WorldService {

	void explode();

	String getName();
}
